
import page from "./lib/page.js";
import renderMiddlewares from "./middlewares/renderMiddlewares.js";
import catalogView from "./views/catalogView.js";
import homeView from "./views/homeView.js";

page(renderMiddlewares)
//setup rout
page('/',homeView)
page('/catalog',catalogView)

//Start routing
page()
