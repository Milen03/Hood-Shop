# Hood Shop

## Description
SoftUni JS Application Course Project. JS end to edn application 


## Tech Stack
* vanilla JS
* FareBase from backend, hosting and authentication
* Tailwind CSS with UI components
* Page.js from routing
* Lit-html for templating 
* Mocha for unit testing
* playwrigth for e2e testing
  
